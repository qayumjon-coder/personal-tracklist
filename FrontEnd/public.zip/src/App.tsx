import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Player } from "./components/Player";
import { Admin } from "./pages/Admin";
import MusicEditor from "./pages/MusicEditor";
import { useFetchSongs } from "./hooks/useFetchSongs";
import { useAudioPlayer } from "./hooks/useAudioPlayer";

export default function App() {
  const { songs, loading } = useFetchSongs("http://localhost:3000/api/songs");
  const player = useAudioPlayer(songs);

  return (
    <Router>
      <div className="w-full min-h-screen flex items-start md:items-center justify-center p-4 py-8 md:py-4 relative overflow-y-auto">
        <div className="retro-grid" />
        <div className="scanline" />
        <Routes>
          <Route path="/" element={<Player songs={songs} loading={loading} player={player} />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/editor" element={<MusicEditor />} />
        </Routes>
      </div>
    </Router>
  );
}
