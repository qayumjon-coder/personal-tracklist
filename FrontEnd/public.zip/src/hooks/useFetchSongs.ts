import { useEffect, useState } from "react";
import type { Song } from "../types/Song";

export function useFetchSongs(apiUrl: string) {
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(apiUrl)
      .then((res) => res.json())
      .then((data) => {
        setSongs(data);
        setLoading(false);
      });
  }, [apiUrl]);

  return { songs, loading };
}
