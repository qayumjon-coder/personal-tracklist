import { useState, useEffect } from "react";

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

type Theme = "aqua" | "green" | "amber" | "pink" | "red";

export function Settings({ isOpen, onClose }: SettingsProps) {
  const [theme, setTheme] = useState<Theme>("aqua");
  const [scanlines, setScanlines] = useState(true);
  const [grid, setGrid] = useState(true);

  // Apply Theme
  useEffect(() => {
    const root = document.documentElement;
    const colors = {
      aqua: { primary: "#00FFFF", secondary: "#008888" },
      green: { primary: "#00FF00", secondary: "#008800" },
      amber: { primary: "#FFB000", secondary: "#885500" },
      pink: { primary: "#FF00FF", secondary: "#880088" },
      red:   { primary: "#FF0000", secondary: "#880000" },
    };

    const selected = colors[theme];
    root.style.setProperty("--text-primary", selected.primary);
    root.style.setProperty("--accent", selected.primary);
    root.style.setProperty("--cursor-color", selected.primary);
    root.style.setProperty("--text-secondary", selected.secondary);
  }, [theme]);

  // Apply Effects
  useEffect(() => {
    const scanlineEl = document.querySelector('.scanline') as HTMLElement;
    const gridEl = document.querySelector('.retro-grid') as HTMLElement;

    if (scanlineEl) scanlineEl.style.display = scanlines ? 'block' : 'none';
    if (gridEl) gridEl.style.display = grid ? 'block' : 'none';
  }, [scanlines, grid]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[var(--bg-main)] border border-[var(--text-primary)] shadow-[0_0_50px_var(--text-secondary)] p-6 relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 border-b border-[var(--text-secondary)] pb-2">
          <h2 className="text-xl font-bold font-mono text-[var(--text-primary)] flex items-center gap-2">
            <span className="animate-pulse">_</span>SYSTEM_CONFIG
          </h2>
          <button 
            onClick={onClose}
            className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-mono text-xl"
          >
            [X]
          </button>
        </div>

        {/* Content */}
        <div className="space-y-8 font-mono">
          
          {/* Theme Selector */}
          <div className="space-y-4">
            <label className="text-[var(--text-secondary)] text-sm uppercase tracking-widest">[ Color Scheme ]</label>
            <div className="grid grid-cols-5 gap-2">
              {(["aqua", "green", "amber", "pink", "red"] as Theme[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setTheme(t)}
                  className={`h-8 w-full border transition-all duration-300 ${
                    theme === t 
                      ? "border-[var(--text-primary)] bg-[var(--text-primary)] shadow-[0_0_10px_var(--text-primary)]" 
                      : "border-[var(--text-secondary)] hover:border-[var(--text-primary)] hover:bg-[var(--text-secondary)]/20"
                  }`}
                  style={{ 
                    // Use a hardcoded color for the button preview since vars change
                    backgroundColor: theme === t ? undefined : 'transparent' 
                  }}
                  title={t}
                >
                  <div className={`w-full h-full ${theme === t ? 'opacity-0' : 'opacity-100'}`} 
                       style={{ backgroundColor: t === 'aqua' ? '#00FFFF' : t === 'green' ? '#00FF00' : t === 'amber' ? '#FFB000' : t === 'pink' ? '#FF00FF' : '#FF0000', opacity: 0.5 }}>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-4">
            <label className="text-[var(--text-secondary)] text-sm uppercase tracking-widest">[ Visual Modules ]</label>
            
            {/* Scanlines */}
            <div className="flex items-center justify-between group cursor-pointer" onClick={() => setScanlines(!scanlines)}>
              <span className={`text-sm ${scanlines ? 'text-[var(--text-primary)]' : 'text-[var(--text-secondary)]'}`}>
                CRT_SCANLINES
              </span>
              <div className={`w-12 h-6 border flex items-center p-0.5 transition-colors ${
                scanlines ? 'border-[var(--text-primary)]' : 'border-[var(--text-secondary)]'
              }`}>
                <div className={`w-4 h-4 bg-[var(--text-primary)] shadow-[0_0_10px_var(--text-primary)] transition-transform duration-300 ${
                  scanlines ? 'translate-x-6' : 'translate-x-0 bg-[var(--text-secondary)] shadow-none'
                }`} />
              </div>
            </div>

            {/* Retro Grid */}
            <div className="flex items-center justify-between group cursor-pointer" onClick={() => setGrid(!grid)}>
              <span className={`text-sm ${grid ? 'text-[var(--text-primary)]' : 'text-[var(--text-secondary)]'}`}>
                RETRO_GRID
              </span>
              <div className={`w-12 h-6 border flex items-center p-0.5 transition-colors ${
                grid ? 'border-[var(--text-primary)]' : 'border-[var(--text-secondary)]'
              }`}>
                <div className={`w-4 h-4 bg-[var(--text-primary)] shadow-[0_0_10px_var(--text-primary)] transition-transform duration-300 ${
                  grid ? 'translate-x-6' : 'translate-x-0 bg-[var(--text-secondary)] shadow-none'
                }`} />
              </div>
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-4 border-t border-[var(--text-secondary)] text-center">
            <button 
                onClick={onClose}
                className="px-8 py-2 border border-[var(--text-primary)] text-[var(--text-primary)] hover:bg-[var(--text-primary)] hover:text-black transition-all font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(0,0,0,0.5)] hover:shadow-[0_0_20px_var(--text-primary)]"
            >
                APPLY & EXIT
            </button>
        </div>

        {/* Decor */}
        <div className="absolute top-0 left-0 w-2 h-2 bg-[var(--text-primary)]"></div>
        <div className="absolute top-0 right-0 w-2 h-2 bg-[var(--text-primary)]"></div>
        <div className="absolute bottom-0 left-0 w-2 h-2 bg-[var(--text-primary)]"></div>
        <div className="absolute bottom-0 right-0 w-2 h-2 bg-[var(--text-primary)]"></div>
      </div>
    </div>
  );
}
