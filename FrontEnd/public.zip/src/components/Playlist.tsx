import type { Song } from "../types/Song";
import { useSoundEffects } from "../hooks/useSoundEffects";

interface PlaylistProps {
  songs: Song[];
  currentSong: Song;
  onSelectSong: (song: Song) => void;
}

export function Playlist({ songs, currentSong, onSelectSong }: PlaylistProps) {
  const { playClick, playHover } = useSoundEffects();

  return (
    <div className="flex flex-col gap-2">
      {songs.map((song, index) => {
        const isActive = song.id === currentSong?.id;
        return (
          <button
            key={song.id}
            onClick={() => { playClick(); onSelectSong(song); }}
            onMouseEnter={playHover}
            className={`w-full flex items-center justify-between gap-3 py-3 px-4 rounded-none transition-all duration-300 group border border-transparent relative overflow-hidden ${
              isActive 
                ? 'bg-[var(--accent)] text-[var(--bg-main)] shadow-[0_0_15px_var(--accent)] scale-[1.02] z-10' 
                : 'hover:bg-[var(--text-secondary)]/10 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--text-secondary)]'
            }`}
            style={{ animation: 'fadeIn 0.5s ease-out forwards', animationDelay: `${index * 0.05}s`, opacity: 0 }}
          >
            <div className="flex items-center gap-4 flex-1 text-left overflow-hidden">
               {/* Animated visualization bars for active track */}
              {isActive ? (
                 <div className="flex gap-0.5 items-end h-3 w-3 shrink-0">
                    <div className="w-1 bg-[var(--bg-main)] animate-[bounce_1s_infinite] rounded-none h-2"></div>
                    <div className="w-1 bg-[var(--bg-main)] animate-[bounce_1.2s_infinite] rounded-none h-3"></div>
                    <div className="w-1 bg-[var(--bg-main)] animate-[bounce_0.8s_infinite] rounded-none h-1"></div>
                 </div>
              ) : (
                <span className="text-xs font-mono w-3 text-[var(--text-secondary)]/50 group-hover:text-[var(--text-secondary)] text-center shrink-0">{index + 1}</span>
              )}

              <div className="flex-1 min-w-0">
                <div className={`text-sm font-medium truncate font-mono ${isActive ? 'text-[var(--bg-main)]' : 'text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]'}`}>
                  {song.title}
                </div>
                <div className={`text-xs truncate font-mono ${isActive ? 'text-[var(--bg-main)]/80' : 'text-[var(--text-secondary)]/70 group-hover:text-[var(--text-secondary)]'}`}>
                  {song.artist}
                </div>
              </div>
            </div>

            <div
              className={`text-xs font-mono w-10 text-right ${isActive ? 'text-[var(--bg-main)]/90' : 'text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]'}`}
            >
              {formatDuration(song.duration)}
            </div>
          </button>
        );
      })}
    </div>
  );
}

function formatDuration(d?: number) {
  if (!d) return '--:--';
  const mins = Math.floor(d / 60);
  const secs = Math.floor(d % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}
