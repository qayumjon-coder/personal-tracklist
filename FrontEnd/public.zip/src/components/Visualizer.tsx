import { useEffect, useRef } from "react";

interface VisualizerProps {
  playing: boolean;
  analyser?: AnalyserNode | null;
}

export function Visualizer({ playing, analyser }: VisualizerProps) {
  // Use 32 bars standard
  const BAR_COUNT = 32;
  const containerRef = useRef<HTMLDivElement>(null);
  const barsRef = useRef<HTMLDivElement[]>([]);
  const animationRef = useRef<number | null>(null);
  
  // Store current values for LERP (Linear Interpolation) smoothing
  const valuesRef = useRef<number[]>(new Array(BAR_COUNT).fill(5));

  useEffect(() => {
    // Collect refs
    if (containerRef.current) {
      barsRef.current = Array.from(containerRef.current.children) as HTMLDivElement[];
    }

    // Prepare data array for frequency data
    const bufferLength = analyser ? analyser.frequencyBinCount : 0;
    const dataArray = new Uint8Array(bufferLength);

    const animate = () => {
      // Get real frequency data if available
      if (playing && analyser) {
        analyser.getByteFrequencyData(dataArray);
      }

      // Calculate target values
      const targetValues = valuesRef.current.map((prevVal, i) => {
        if (!playing || !analyser) {
          // Decay to 5% if paused
          return Math.max(5, prevVal * 0.9);
        }

        // Map the 32 bars to the useful part of the frequency spectrum (usually lower half of fftSize)
        // We skip the very low frequencies (index 0-2) and spread across roughly index 0 to 40-50
        // Step size implies how many frequency bins we "skip" or average
        const dataIndex = Math.floor(i * 1.5) + 2; 
        const rawValue = dataArray[dataIndex] || 0;

        // Scale raw 0-255 to percentage 5-100
        // Boosting basics: (val / 255) * 100 * boost
        let target = (rawValue / 255) * 100 * 1.2; 
        
        return Math.max(5, Math.min(100, target));
      });

      // Apply LERP and update DOM directly
      valuesRef.current = valuesRef.current.map((prev, i) => {
        const target = targetValues[i];
        // LERP factor: 0.2 gives a nice weighted/soft feel
        const next = prev + (target - prev) * 0.2; 
        
        const bar = barsRef.current[i];
        if (bar) {
          bar.style.height = `${next}%`;
        }
        return next;
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [playing, analyser]);

  return (
    <div ref={containerRef} className="flex items-end justify-center gap-1 h-full w-full px-4" aria-hidden="true">
      {Array.from({ length: BAR_COUNT }).map((_, i) => (
        <div
          key={i}
          className="w-full max-w-[12px] rounded-none will-change-transform"
          style={{
            height: `5%`, // Initial height
            background: `linear-gradient(to top, var(--accent) 20%, transparent 100%)`,
            opacity: 0.9
          }}
        />
      ))}
    </div>
  );
}