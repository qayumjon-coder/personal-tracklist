import { useSoundEffects } from "../hooks/useSoundEffects";

interface PlaybackControlsProps {
  playing: boolean;
  shuffle: boolean;
  repeat: "off" | "one" | "all";
  onPlay: () => void;
  onPause: () => void;
  onPrev: () => void;
  onNext: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
}

export function PlaybackControls({
  playing,
  shuffle,
  repeat,
  onPlay,
  onPause,
  onPrev,
  onNext,
  onToggleShuffle,
  onToggleRepeat,
}: PlaybackControlsProps) {
  const iconBaseClass = "w-5 h-5 fill-current";
  const { playClick, playHover } = useSoundEffects();
  
  return (
    <div className="flex items-center justify-center gap-6">
      {/* Shuffle */}
      <button
        onClick={() => { playClick(); onToggleShuffle(); }}
        onMouseEnter={playHover}
        className={`p-2 rounded-none border transition-all duration-300 ${
          shuffle 
            ? 'text-[var(--bg-main)] bg-[var(--accent)] border-[var(--accent)] shadow-[0_0_15px_var(--accent)]' 
            : 'text-[var(--text-secondary)] border-transparent hover:text-[var(--accent)] hover:border-[var(--text-secondary)]'
        }`}
        title="Shuffle"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className={iconBaseClass}>
          <path d="M17.0001 7.00002L19.5859 9.58581L21.0001 8.1716L16.0001 3.1716L11.0001 8.1716L12.4143 9.58581L15.0001 7.00002V17C15.0001 19.2092 13.2092 21 11.0001 21H3.00009V19H11.0001C12.1047 19 13.0001 18.1046 13.0001 17V7.00002ZM11.0001 3.00002L12.4143 4.41424L9.82852 7.00002H3.00009V9.00002H9.82852L11.0001 9.00002V17C11.0001 17.5523 10.5524 18 10.0001 18H3.00009V20H10.0001C11.657 20 13.0001 18.6569 13.0001 17V9.00002L16.0001 12L21.0001 7.00002L16.0001 2.00002L11.0001 7.00002L12.4143 8.41424L11.0001 3.00002ZM4.00009 11H13.0001C13.5524 11 14.0001 11.4477 14.0001 12V20H16.0001V12C16.0001 10.3432 14.657 9.00002 13.0001 9.00002H4.00009V11ZM18.0001 15V22H20.0001V15H18.0001Z" fillOpacity="0" />
          <path d="M10.5859 12L8.58588 14H3.00009V16H8.58588L11.1717 13.4142L12.5859 14.8284L7.58588 19.8284L2.58588 14.8284L4.00009 13.4142L5.41431 14.8284H9.17166L10.5859 13.4142L7.00009 12H3.00009V10H7.00009L10.5859 13.5858L10.5859 12ZM21.4143 15.4142L20.0001 14L15.0001 19L20.0001 24L21.4143 22.5858L18.8285 20H13.0001V18H18.8285L21.4143 15.4142Z" />
        </svg>
      </button>

      {/* Previous */}
      <button
        onClick={() => { playClick(); onPrev(); }}
        onMouseEnter={playHover}
        className="p-3 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-none hover:bg-[var(--text-secondary)]/10 transition-colors"
        title="Previous"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-6 h-6 fill-current">
          <path d="M19 4V20H17V4H19ZM6.99997 12L15 19V5L6.99997 12ZM13 9.85714V14.1429L10.5511 12L13 9.85714ZM5.00002 19V5H3.00002V19H5.00002Z" />
        </svg>
      </button>

      {/* Play/Pause */}
      <button
        onClick={() => { playClick(); playing ? onPause() : onPlay(); }}
        onMouseEnter={playHover}
        className="w-16 h-16 rounded-none flex items-center justify-center bg-[var(--accent)] text-[var(--bg-main)] shadow-[0_0_30px_var(--accent)] hover:shadow-[0_0_50px_var(--accent)] transition-all duration-300 group border border-[var(--cursor-color)]"
        title={playing ? "Pause" : "Play"}
      >
        {playing ? (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-8 h-8 fill-current group-hover:scale-110 transition-transform">
            <path d="M6 5H8V19H6V5ZM16 5H18V19H16V5Z" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-8 h-8 fill-current ml-1 group-hover:scale-110 transition-transform">
            <path d="M8 5V19L19 12L8 5Z" />
          </svg>
        )}
      </button>

      {/* Next */}
      <button
        onClick={() => { playClick(); onNext(); }}
        onMouseEnter={playHover}
        className="p-3 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-none hover:bg-[var(--text-secondary)]/10 transition-colors"
        title="Next"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-6 h-6 fill-current">
          <path d="M5.00003 4V20H7.00003V4H5.00003ZM17 12L9.00003 5V19L17 12ZM11 14.1429V9.85714L13.449 12L11 14.1429ZM19 19V5H21V19H19Z" />
        </svg>
      </button>

      {/* Repeat */}
      <button
        onClick={() => { playClick(); onToggleRepeat(); }}
        onMouseEnter={playHover}
        className={`p-2 rounded-none border transition-all duration-300 relative ${
          repeat !== 'off' 
            ? 'text-[var(--bg-main)] bg-[var(--accent)] border-[var(--accent)] shadow-[0_0_15px_var(--accent)]' 
            : 'text-[var(--text-secondary)] border-transparent hover:text-[var(--accent)] hover:border-[var(--text-secondary)]'
        }`}
        title={`Repeat: ${repeat}`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className={iconBaseClass}>
          <path d="M17 17H7V14L2 18L7 22V19H19V13H17V17ZM7 7H17V10L22 6L17 2V5H5V11H7V7Z" />
        </svg>
        {repeat === 'one' && (
          <span className="absolute -top-1 -right-1 text-[8px] flex items-center justify-center w-4 h-4 bg-[var(--accent)] text-white rounded-full font-bold">1</span>
        )}
      </button>
    </div>
  );
}