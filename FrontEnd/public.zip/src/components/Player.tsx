import type { Song } from "../types/Song";
import { Link } from "react-router-dom";

import { useAudioPlayer } from "../hooks/useAudioPlayer";
import { Playlist } from "./Playlist";
import { ProgressBar } from "./ProgressBar";
import { PlaybackControls } from "./PlaybackControls";
import { VolumeControl } from "./VolumeControl";
import { Visualizer } from "./Visualizer";
import { Settings } from "./Settings";
import { formatTime } from "../utils/formatTime";
import { useState } from "react";


import { useSoundEffects } from "../hooks/useSoundEffects";

interface PlayerProps {
  songs: Song[];
  loading: boolean;
  player: ReturnType<typeof useAudioPlayer>;
}

export function Player({ songs, loading, player }: PlayerProps) {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { playClick, playHover } = useSoundEffects();
  const [isConfigMenuOpen, setIsConfigMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", ...Array.from(new Set(songs.map(s => s.category || "General")))];
  const filteredSongs = selectedCategory === "All" ? songs : songs.filter(s => (s.category || "General") === selectedCategory);

  if (loading) return <div className="text-[var(--text-primary)] text-center mt-20 text-lg animate-pulse font-mono">Loading library...</div>;
  if (!songs.length) return <div className="text-[var(--text-secondary)] text-center mt-20 font-mono">No songs found in library</div>;

  const current: Song = songs[player.index];

  return (
    <>
    <Settings isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    
    <div className="relative w-full max-w-5xl mx-auto flex flex-col overflow-hidden min-h-[auto] md:min-h-[500px] md:h-[550px] border border-[var(--text-secondary)] bg-[var(--bg-main)] shadow-[0_0_40px_rgba(0,255,255,0.1)] text-base md:text-lg">
    {/* Decorative Corners */}
    <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[var(--accent)] z-20"></div>
    <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[var(--accent)] z-20"></div>
    <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[var(--accent)] z-20"></div>
    <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[var(--accent)] z-20"></div>

    {/* Top Toolbar - Dedicated Row */}
    <div className="w-full h-10 md:h-12 border-b border-[var(--text-secondary)]/30 flex items-center justify-between px-3 md:px-4 bg-[var(--text-secondary)]/5 z-30 shrink-0">
       {/* Status Status */}
       <div className="flex items-center gap-2">
         <div className={`w-2 h-2 rounded-full ${player.playing ? 'bg-[var(--accent)] animate-pulse shadow-[0_0_10px_var(--accent)]' : 'bg-[var(--text-secondary)]'}`}></div>
         <span className="text-[10px] font-mono text-[var(--text-secondary)] tracking-widest">{player.playing ? 'PLAYING' : 'READY'}</span>
       </div>

       {/* Controls */}
       <div className="flex items-center gap-2">
          <Link 
              to="/admin"
              onClick={playClick}
              onMouseEnter={playHover}
              className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-mono text-xs border border-[var(--text-secondary)]/50 hover:border-[var(--text-primary)] px-2 py-1 transition-all bg-black/50"
          >
              [ UPLOAD ]
          </Link>
          <Link 
            to="/editor"
            onClick={playClick}
            onMouseEnter={playHover}
            className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-mono text-xs border border-[var(--text-secondary)]/50 hover:border-[var(--text-primary)] px-2 py-1 transition-all bg-black/50"
          >
            [ EDITOR ]
          </Link>
          <div className="relative">
            <button 
              onClick={() => { playClick(); setIsSettingsOpen(true); }}
              onMouseEnter={playHover}
              className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-mono text-xs border border-[var(--text-secondary)]/50 hover:border-[var(--text-primary)] px-2 py-1 transition-all bg-black/50"
            >
              [ CONFIG ]
            </button>
          </div>

          <div className="relative">
             <button
               onClick={() => { playClick(); setIsConfigMenuOpen(!isConfigMenuOpen); }}
               onMouseEnter={playHover}
               className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-mono text-xs border border-[var(--text-secondary)]/50 hover:border-[var(--text-primary)] px-2 py-1 transition-all bg-black/50 h-[26px] flex items-center"
             >
               {isConfigMenuOpen ? '▴' : '▾'}
             </button>
             
             {isConfigMenuOpen && (
               <div className="absolute right-0 top-full mt-1 w-40 bg-[var(--bg-main)] border border-[var(--text-secondary)] z-50 shadow-xl">
                 <div className="p-1 max-h-48 overflow-y-auto custom-scrollbar">
                   {categories.map(cat => (
                     <button
                       key={cat}
                       onClick={() => { playClick(); setSelectedCategory(cat); setIsConfigMenuOpen(false); }}
                       className={`w-full text-left px-3 py-2 text-[10px] font-mono uppercase tracking-wider transition-all border-b border-[var(--text-secondary)]/10 last:border-0 ${
                         selectedCategory === cat 
                           ? 'bg-[var(--accent)] text-black font-bold' 
                           : 'text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--text-secondary)]/10'
                       }`}
                     >
                       {cat}
                     </button>
                   ))}
                 </div>
               </div>
             )}
          </div>
       </div>
    </div>
      
    {/* Main Content Area */}
    <div className="flex-1 flex flex-col md:flex-row overflow-visible md:overflow-hidden relative">
      {/* Left Column: Player Focus */}
      <div className="flex-1 p-4 md:p-8 flex flex-col justify-start md:justify-center relative z-10 overflow-visible md:overflow-hidden">
        {/* Background glow for ambience */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-[var(--accent)] opacity-20 blur-[100px] rounded-full pointer-events-none" />
        
        {/* Dynamic Visualizer Background */}
        <div className="absolute bottom-0 left-0 right-0 h-48 opacity-20 pointer-events-none mix-blend-screen">
           <Visualizer playing={player.playing} analyser={player.analyser} />
        </div>

        {/* Cover Art */}
        <div className="relative w-full max-w-[10rem] md:max-w-[14rem] mx-auto aspect-square rounded-none overflow-hidden border border-[var(--text-secondary)] mb-4 transition-transform duration-500 hover:scale-[1.02] shadow-[0_0_16px_var(--accent)] group">
          <img 
            src={current.coverUrl} 
            alt={current.title} 
            className="w-full h-full rounded-none object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-500"
          />
          {/* Overlay Grid on Cover */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 bg-[length:100%_2px,3px_100%] pointer-events-none opacity-20 group-hover:opacity-10 transition-opacity"></div>
        </div>

        {/* Track Info */}
        <div className="text-center mb-4 space-y-1">
          <h2 className="text-2xl md:text-3xl font-bold text-[var(--text-primary)] tracking-tight drop-shadow-md truncate font-mono">
            {current.title}
          </h2>
          <p className="text-base text-[var(--text-secondary)] font-medium">
            {current.artist}
          </p>
        </div>

        {/* Category list removed per request */}

        {/* Progress Component */}
        <div className="w-full max-w-sm mx-auto mb-4 space-y-2">
          <ProgressBar 
            progress={player.progress} 
            onSeek={player.seek} 
            duration={player.duration} 
          />
          <div className="flex justify-between text-xs font-mono text-[var(--text-secondary)] font-medium px-1">
            <span>{formatTime(player.currentTime)}</span>
            <span>{formatTime(player.duration)}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="w-full max-w-md mx-auto flex flex-col items-center gap-4">
          <PlaybackControls
            playing={player.playing}
            shuffle={player.shuffle}
            repeat={player.repeat}
            onPlay={player.play}
            onPause={player.pause}
            onPrev={player.prev}
            onNext={player.next}
            onToggleShuffle={player.toggleShuffle}
            onToggleRepeat={player.toggleRepeat}
          />
          
          <div className="w-2/3">
            <VolumeControl
              volume={player.volume}
              isMuted={player.isMuted}
              onVolumeChange={player.setVolume}
              onToggleMute={player.toggleMute}
            />
          </div>
        </div>
      </div>

      {/* Right Column: Playlist */}
      <div className="w-full md:w-[300px] h-[200px] md:h-auto bg-[var(--bg-main)] border-t md:border-t-0 md:border-l border-[var(--text-secondary)] flex flex-col">
        {/* categories moved to left */}

        <div className="p-4 border-b border-[var(--text-secondary)] bg-[var(--text-secondary)]/5">
          <h3 className="text-lg font-bold text-[var(--text-primary)] tracking-wide font-mono">TRACKLIST</h3>
          <p className="text-xs text-[var(--text-secondary)] mt-1 font-medium font-mono">{filteredSongs.length} Tracks</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
          <Playlist
            songs={filteredSongs}
            currentSong={songs[player.index]}
            onSelectSong={(song) => {
                const idx = songs.findIndex(s => s.id === song.id);
                if (idx !== -1) player.selectSong(idx);
            }}
          />
        </div>
      </div>
    </div>
    </div>
    </>
  );
}
