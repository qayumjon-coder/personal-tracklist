export async function getMusicList() {
  const response = await fetch("http://localhost:3000/api/songs");
  if (!response.ok) throw new Error("Failed to fetch music list");
  return response.json();
}
