export interface Song {
  id: number;
  title: string;
  artist: string;
  url: string;
  coverUrl: string;
  duration: number;
  category: string;
}

